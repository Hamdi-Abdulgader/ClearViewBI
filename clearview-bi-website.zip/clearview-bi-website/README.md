# ClearView BI Website

Professionele one-pager website voor ClearView BI - Business Intelligence Consultancy.

## 📁 Folder structuur

```
clearview-bi-website/
├── index.html          # Hoofdpagina (alles-in-één)
├── images/
│   ├── logo-icon.jpg   # Logo icoon (zonder tekst)
│   └── logo-full.jpg   # Volledig logo (met tekst)
└── README.md           # Dit bestand
```

## 🚀 Hoe te gebruiken

### Lokaal bekijken
1. Open de folder `clearview-bi-website`
2. Dubbelklik op `index.html`
3. De website opent in je browser

### Uploaden naar hosting

#### Wix
1. Gebruik Wix Editor om de secties na te bouwen
2. Kopieer de teksten uit de HTML
3. Upload de logo's via Media Manager

#### Webflow
1. Maak een nieuw project aan
2. Bouw de secties na met de Designer
3. Gebruik de structuur als referentie

#### WordPress (Elementor)
1. Installeer Elementor plugin
2. Maak een nieuwe pagina aan
3. Bouw de secties na met drag & drop

#### Netlify / Vercel (gratis hosting)
1. Maak een account aan op netlify.com of vercel.com
2. Sleep de hele folder naar de upload zone
3. Je website is live!

#### Traditionele hosting
1. Upload alle bestanden via FTP
2. Zorg dat index.html in de root staat

## ✏️ Aanpassen

### Contactgegevens wijzigen
Open `index.html` en zoek naar:
- `contact@clearviewbi.nl` → vervang door je echte e-mail
- `+31 6 12 34 56 78` → vervang door je echte nummer
- `linkedin.com/in/clearviewbi` → vervang door je LinkedIn URL

### Kleuren aanpassen
Zoek in de CSS naar:
```css
--orange-500: #F5A623;  /* Hoofdkleur (oranje) */
--slate-800: #1E293B;   /* Donkerblauw */
```

### Cases aanpassen
Zoek naar de `<!-- Cases Section -->` en pas de teksten aan met je eigen projecten.

## 🎨 Kleurenpalet

| Kleur | Hex | Gebruik |
|-------|-----|---------|
| Oranje | #F5A623 | Buttons, accenten, highlights |
| Donkerblauw | #1E293B | Tekst, donkere secties |
| Lichtgrijs | #F8FAFC | Achtergronden |

## 📱 Features

- ✅ Volledig responsive (desktop, tablet, mobiel)
- ✅ Smooth scroll navigatie
- ✅ Mobiel hamburger menu
- ✅ Hover effecten op cards
- ✅ Contactformulier (placeholder)
- ✅ Lucide iconen (via CDN)
- ✅ Google Fonts (Inter)

## 💡 Tips

1. **Logo's vervangen**: Upload je PNG-versies van de logo's voor betere kwaliteit
2. **Formulier koppelen**: Gebruik Formspree.io of Netlify Forms voor echte form submissions
3. **Analytics**: Voeg Google Analytics toe voor bezoekersstatistieken
4. **SEO**: Pas de meta description aan in de `<head>` sectie

## 📞 Support

Vragen over de website? Neem contact op via het contactformulier.

---

© 2025 ClearView BI
