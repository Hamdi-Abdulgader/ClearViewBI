import React, { useState } from 'react';
import { ChevronRight, BarChart3, Database, TrendingUp, Zap, Users, CheckCircle, Mail, Phone, Linkedin, ArrowRight, Menu, X } from 'lucide-react';

export default function ClearViewBI() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const services = [
    {
      icon: <BarChart3 className="w-8 h-8" />,
      title: "Power BI Dashboards",
      description: "Op maat gemaakte dashboards die uw KPI's visueel en interactief presenteren. Van productie-overzichten tot financiële rapportages."
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "Datamodellering & SQL",
      description: "Efficiënte datastructuren en geoptimaliseerde queries voor snelle, betrouwbare data-oplevering uit meerdere bronnen."
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "DAX & Berekeningen",
      description: "Complexe berekeningen vertaald naar begrijpelijke KPI's. Van rolling averages tot time-intelligence."
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Excel → Power BI",
      description: "Vervang foutgevoelige spreadsheets door geautomatiseerde, schaalbare Power BI-oplossingen."
    }
  ];

  const usps = [
    { title: "Kwaliteit & Nauwkeurigheid", description: "Grondig gevalideerde rapportages met volledige documentatie" },
    { title: "Snelheid & Efficiëntie", description: "Werkend prototype binnen 1-2 weken" },
    { title: "Helder Communiceren", description: "Techniek vertaald naar begrijpelijke taal" },
    { title: "Praktische Inzichten", description: "Actionable KPI's waar u direct mee aan de slag kunt" },
    { title: "Procesbegrip", description: "Combinatie van BI-expertise én kennis van productieprocessen" }
  ];

  const cases = [
    {
      title: "Productie Dashboard",
      client: "Maakindustrie",
      description: "Real-time OEE monitoring met drill-down naar machine-niveau. Resultaat: 15% reductie in ongeplande stilstand.",
      tags: ["Power BI", "SQL", "OEE"]
    },
    {
      title: "Kostprijsanalyse",
      client: "Metaalbewerking",
      description: "Geïntegreerde kostprijsrapportage met waterfall-charts voor variance analysis per productlijn.",
      tags: ["DAX", "Financieel", "Power BI"]
    },
    {
      title: "Excel Migratie",
      client: "Logistiek",
      description: "Van 12 losse Excel-bestanden naar één geautomatiseerd Power BI rapport met dagelijkse refresh.",
      tags: ["Migratie", "Automatisering"]
    }
  ];

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm z-50 border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 relative">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  <circle cx="50" cy="50" r="35" fill="none" stroke="#F5A623" strokeWidth="8" strokeLinecap="round" 
                    strokeDasharray="50 20" transform="rotate(-45 50 50)"/>
                  <line x1="25" y1="75" x2="75" y2="25" stroke="#F5A623" strokeWidth="8" strokeLinecap="round"/>
                  <line x1="35" y1="85" x2="85" y2="35" stroke="#F5A623" strokeWidth="8" strokeLinecap="round"/>
                </svg>
              </div>
              <span className="text-xl font-bold text-slate-800">Clear<span className="text-slate-600">View</span> <span className="text-slate-800">BI</span></span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#diensten" className="text-slate-600 hover:text-orange-500 transition-colors">Diensten</a>
              <a href="#waarom" className="text-slate-600 hover:text-orange-500 transition-colors">Waarom ik</a>
              <a href="#cases" className="text-slate-600 hover:text-orange-500 transition-colors">Cases</a>
              <a href="#contact" className="bg-orange-500 hover:bg-orange-600 text-white px-5 py-2.5 rounded-lg font-medium transition-colors">
                Contact
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 flex flex-col gap-4">
              <a href="#diensten" className="text-slate-600">Diensten</a>
              <a href="#waarom" className="text-slate-600">Waarom ik</a>
              <a href="#cases" className="text-slate-600">Cases</a>
              <a href="#contact" className="bg-orange-500 text-white px-5 py-2.5 rounded-lg font-medium text-center">Contact</a>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 bg-gradient-to-br from-slate-50 via-white to-orange-50">
        <div className="max-w-6xl mx-auto">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-700 px-4 py-1.5 rounded-full text-sm font-medium mb-6">
              <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
              Business Intelligence Consultant
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-800 leading-tight mb-6">
              Van ruwe data naar{' '}
              <span className="text-orange-500">heldere inzichten</span>
            </h1>
            
            <p className="text-xl text-slate-600 leading-relaxed mb-8 max-w-2xl">
              Ik help organisaties grip te krijgen op hun data. Met Power BI dashboards en 
              datamodellen die niet alleen mooi zijn, maar direct bijdragen aan betere besluitvorming.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="#contact" className="inline-flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors">
                Vrijblijvend kennismaken
                <ArrowRight className="w-5 h-5" />
              </a>
              <a href="#diensten" className="inline-flex items-center justify-center gap-2 border-2 border-slate-200 hover:border-slate-300 text-slate-700 px-8 py-4 rounded-lg font-semibold text-lg transition-colors">
                Bekijk mijn diensten
              </a>
            </div>

            {/* Trust indicators */}
            <div className="mt-12 pt-8 border-t border-slate-200">
              <div className="flex flex-wrap gap-8 text-slate-500 text-sm">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Ervaring in maakindustrie</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Microsoft Certified</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Eerste resultaat binnen 2 weken</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="diensten" className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">Wat ik voor u kan betekenen</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Van dashboard-ontwikkeling tot complete datamodellering — altijd gericht op praktisch resultaat.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="group p-8 bg-slate-50 rounded-2xl hover:bg-white hover:shadow-xl transition-all duration-300 border border-transparent hover:border-slate-100">
                <div className="w-14 h-14 bg-orange-100 rounded-xl flex items-center justify-center text-orange-500 mb-6 group-hover:bg-orange-500 group-hover:text-white transition-colors">
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3">{service.title}</h3>
                <p className="text-slate-600 leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Me Section */}
      <section id="waarom" className="py-20 px-6 bg-slate-800">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Waarom ClearView BI?</h2>
            <p className="text-lg text-slate-300 max-w-2xl mx-auto">
              Wat mij onderscheidt van andere BI-consultants
            </p>
          </div>

          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6">
            {usps.map((usp, index) => (
              <div key={index} className="bg-slate-700/50 rounded-xl p-6 text-center hover:bg-slate-700 transition-colors">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-white mb-2 text-lg">{usp.title}</h3>
                <p className="text-slate-400 text-sm">{usp.description}</p>
              </div>
            ))}
          </div>

          {/* Quote */}
          <div className="mt-16 text-center">
            <blockquote className="text-2xl text-slate-300 italic max-w-3xl mx-auto">
              "Mijn achtergrond in Technische Bedrijfskunde én dagelijkse ervaring in de maakindustrie 
              geeft mij een unieke combinatie. Ik begrijp niet alleen de data, maar ook de processen erachter."
            </blockquote>
          </div>
        </div>
      </section>

      {/* Cases Section */}
      <section id="cases" className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">Voorbeeldprojecten</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Een greep uit recente opdrachten
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {cases.map((caseItem, index) => (
              <div key={index} className="group bg-white rounded-2xl overflow-hidden border border-slate-200 hover:border-orange-200 hover:shadow-lg transition-all">
                {/* Placeholder image area */}
                <div className="h-48 bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                  <BarChart3 className="w-16 h-16 text-slate-300" />
                </div>
                <div className="p-6">
                  <div className="text-sm text-orange-500 font-medium mb-2">{caseItem.client}</div>
                  <h3 className="text-xl font-bold text-slate-800 mb-3">{caseItem.title}</h3>
                  <p className="text-slate-600 text-sm mb-4">{caseItem.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {caseItem.tags.map((tag, tagIndex) => (
                      <span key={tagIndex} className="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-6 bg-gradient-to-r from-orange-500 to-orange-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Klaar om uw data te laten werken?
          </h2>
          <p className="text-xl text-orange-100 mb-8">
            Laten we vrijblijvend kennismaken en bespreken wat ik voor u kan betekenen.
          </p>
          <a href="#contact" className="inline-flex items-center gap-2 bg-white text-orange-600 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-orange-50 transition-colors">
            Plan een gesprek
            <ChevronRight className="w-5 h-5" />
          </a>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16">
            {/* Contact Info */}
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">Neem contact op</h2>
              <p className="text-lg text-slate-600 mb-8">
                Benieuwd wat ClearView BI voor uw organisatie kan betekenen? 
                Neem vrijblijvend contact op voor een kennismakingsgesprek.
              </p>

              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Mail className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <div className="text-sm text-slate-500">E-mail</div>
                    <div className="font-medium text-slate-800">contact@clearviewbi.nl</div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Phone className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <div className="text-sm text-slate-500">Telefoon</div>
                    <div className="font-medium text-slate-800">+31 6 12 34 56 78</div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Linkedin className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <div className="text-sm text-slate-500">LinkedIn</div>
                    <div className="font-medium text-slate-800">linkedin.com/in/clearviewbi</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Naam</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-colors"
                    placeholder="Uw naam"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">E-mail</label>
                  <input 
                    type="email" 
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-colors"
                    placeholder="uw@email.nl"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Bericht</label>
                  <textarea 
                    rows={4}
                    className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-colors resize-none"
                    placeholder="Vertel kort waar u naar op zoek bent..."
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-lg font-semibold text-lg transition-colors flex items-center justify-center gap-2"
                >
                  Verstuur bericht
                  <ArrowRight className="w-5 h-5" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 bg-slate-800 text-slate-400">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <circle cx="50" cy="50" r="35" fill="none" stroke="#F5A623" strokeWidth="8" strokeLinecap="round" 
                  strokeDasharray="50 20" transform="rotate(-45 50 50)"/>
                <line x1="25" y1="75" x2="75" y2="25" stroke="#F5A623" strokeWidth="8" strokeLinecap="round"/>
                <line x1="35" y1="85" x2="85" y2="35" stroke="#F5A623" strokeWidth="8" strokeLinecap="round"/>
              </svg>
            </div>
            <span className="font-semibold text-white">ClearView BI</span>
          </div>
          <div className="text-sm">
            © 2025 ClearView BI. Alle rechten voorbehouden.
          </div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-orange-500 transition-colors">Privacy</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Voorwaarden</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
